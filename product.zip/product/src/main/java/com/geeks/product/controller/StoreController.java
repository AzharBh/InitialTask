package com.geeks.product.controller;

import com.geeks.product.beans.Store;
import com.geeks.product.repository.StoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/store")
public class StoreController {

    @Autowired
    private StoreRepository storeRepository;

    @PostMapping
    public ResponseEntity saveOrUpdateStore(@RequestBody Store store){
        return ResponseEntity.ok(storeRepository.save(store));
    }

    @GetMapping("{id}")
    public ResponseEntity getSingleStore(@PathVariable Integer id){
        if(!storeRepository.existsById(id)){
            return new ResponseEntity("Store Not Found", HttpStatus.BAD_REQUEST);
        }
        return ResponseEntity.ok(storeRepository.getOne(id));
    }

    @GetMapping
    public ResponseEntity getAllStores(){
        return ResponseEntity.ok(storeRepository.findAll());
    }

    @DeleteMapping("{id}")
    public ResponseEntity deleteSingleStore(@PathVariable Integer id){
        if(!storeRepository.existsById(id)){
            return new ResponseEntity("Store Not Found", HttpStatus.BAD_REQUEST);
        }
        storeRepository.deleteById(id);
        return new ResponseEntity("Deleted Successfully", HttpStatus.OK);
    }


}
