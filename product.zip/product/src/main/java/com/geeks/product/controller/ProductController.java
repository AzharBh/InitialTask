package com.geeks.product.controller;

import com.geeks.product.beans.Product;
import com.geeks.product.beans.StoreProducts;
import com.geeks.product.repository.ProductRepository;
import com.geeks.product.repository.StoreProductRepository;
import com.geeks.product.repository.StoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/product")
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private StoreRepository storeRepository;

    @Autowired
    private StoreProductRepository storeProductRepository;

    @PostMapping
    public ResponseEntity addOrUpdateProduct(@RequestBody Product product){
        if(product.getStore().size() == 0){
            return new ResponseEntity("Plz Select Store First", HttpStatus.BAD_REQUEST);
        }
       Product product1 =  productRepository.save(product);
        product.getStore().forEach(i->{
            if(storeRepository.existsById(i.getId())){
                StoreProducts sp = new StoreProducts();
                sp.setProduct(product1);
                sp.setStore(storeRepository.getOne(i.getId()));
                storeProductRepository.save(sp);
            }
        });

        return ResponseEntity.ok(product1);
    }

    @GetMapping("/store/{id}")
    public ResponseEntity findProductByStore(@PathVariable Integer id){
        if(!storeRepository.existsById(id)){
            return new ResponseEntity("Store Not Found", HttpStatus.BAD_REQUEST);
        }
        return ResponseEntity.ok(storeProductRepository.findByStore(storeRepository.getOne(id)));
    }




    @DeleteMapping("{id}")
    public ResponseEntity deleteProduct(@PathVariable Integer id){
        if(!productRepository.existsById(id)){
            return new ResponseEntity("Product Not Found", HttpStatus.BAD_REQUEST);
        }
        productRepository.deleteById(id);

        return new ResponseEntity("Product Deleted Successfully", HttpStatus.OK);

    }

    @GetMapping("{id}")
    public ResponseEntity getSingleProduct(@PathVariable Integer id){
        if(!productRepository.existsById(id)){
            return new ResponseEntity("Product Not Found", HttpStatus.BAD_REQUEST);
        }
        return ResponseEntity.ok(productRepository.getOne(id));
    }

    @GetMapping
    public ResponseEntity getAllProducts(){
        return ResponseEntity.ok(productRepository.findAll());
    }

}
