package com.geeks.product.beans;

public enum BatchStatus {
	Start, In_Process, EndStage, Complete;
}
